<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Ucapan Ulang Tahun Islami untuk Fara</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&family=Satisfy&family=Poppins:wght@400;600&display=swap');

* {
    box-sizing: border-box;
}
body, html {
    margin: 0; padding: 0;
    height: 100%;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(120deg, #c2e9fb 0%, #81a4fd 100%);
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #1c2a4d;
    text-align: center;
    position: relative;
}
body::before {
    content: '';
    position: fixed;
    top: -15%;
    left: -10%;
    width: 130%;
    height: 130%;
    background-image:
        radial-gradient(circle at 30% 30%, rgba(255 255 255 / 0.2) 0%, transparent 75%),
        radial-gradient(circle at 70% 70%, rgba(255 255 255 / 0.1) 0%, transparent 75%);
    z-index: 0;
    pointer-events: none;
    animation: sway 15s ease-in-out infinite alternate;
}
@keyframes sway {
    0% {transform: translate(0,0);}
    100% {transform: translate(15px,10px);}
}

.card {
    position: relative;
    background: #ffffffcc;
    max-width: 450px;
    width: 90vw;
    padding: 35px 30px 45px 30px;
    border-radius: 25px;
    box-shadow: 0 10px 30px rgba(30, 60, 180, 0.3);
    backdrop-filter: blur(10px);
    z-index: 10;
}

h1 {
    font-family: 'Dancing Script', cursive;
    font-size: 3.4rem;
    margin-bottom: 0.25em;
    color: #3b5998;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.15);
}
p {
    font-size: 1.15rem;
    line-height: 1.5;
    color: #1e2a38;
    font-weight: 500;
    min-height: 120px;
}

button {
    background-color: #4a90e2;
    border: none;
    color: white;
    padding: 14px 36px;
    font-size: 1.1rem;
    font-weight: 700;
    border-radius: 35px;
    cursor: pointer;
    box-shadow: 0 6px 12px #4a90e288;
    transition: 0.3s ease;
    min-width: 140px;
}
button:hover:not(:disabled) {
    background-color: #3a78c0;
}
button:disabled {
    background-color: #aaa;
    cursor: default;
    box-shadow: none;
}

canvas.confetti {
    position: fixed;
    top: 0; left: 0;
    pointer-events: none;
    width: 100vw;
    height: 100vh;
    z-index: 5;
}

.balloon-container {
    position: fixed;
    bottom: -150px;
    left: 0;
    width: 100vw;
    height: 100vh;
    pointer-events: none;
    z-index: 3;
}
svg.balloon {
    position: absolute;
    width: 40px;
    height: 70px;
    animation-name: floatUpDown;
    animation-timing-function: ease-in-out;
    animation-iteration-count: infinite;
}
@keyframes floatUpDown {
    0%, 100% {
        transform: translateY(0) translateX(0);
    }
    50% {
        transform: translateY(-25px) translateX(10px);
    }
}

.typing {
    display: inline-block;
    white-space: pre-wrap;
    border-right: 2px solid #333;
    animation: caret 1s step-end infinite;
}
@keyframes caret {
    0%, 100% { border-color: transparent; }
    50% { border-color: #333; }
}
</style>
</head>
<body>
<div class="card">
    <h1 id="title">Hai Fara</h1>
    <p id="message"><span id="typingText" class="typing"></span></p>
    <button id="nextBtn">Selanjutnya &rarr;</button>
</div>
<div class="balloon-container" id="balloonContainer"></div>
<canvas class="confetti" id="confettiCanvas"></canvas>

<script>
const steps = [
    { title: 'Hai Fara', message: 'Klik tombol "Selanjutnya"!' },
    { title: 'Hari Ini Kamu Udah 19 Tahun Aja ya hehe', message: 'Semoga Allah SWT selalu memberkahi dan melindungi setiap langkah kamu dalam meraih cita cita.' },
    { title: 'Barakallahu fii umrik Fara ✨', message:
        'Semoga Allah Ta\'ala terus melimpahkan rahmat, keberkahan, dan hidayahnya untuk kamu.\n' +
        'Semoga kamu selalu dianugerahi kesehatan, kebahagiaan, dan kesuksesan dalam hidup di dunia dan akhirat.\n' +
        'Aamiin ya Rabbal \'alamiin'
    },
];

let currentStep = 0;
const titleEl = document.getElementById('title');
const typingTextEl = document.getElementById('typingText');
const nextBtn = document.getElementById('nextBtn');

function typeText(text, i = 0) {
    if (i <= text.length) {
        typingTextEl.textContent = text.substring(0, i);
        setTimeout(() => typeText(text, i + 1), 30);
    }
}

function showStep(step) {
    titleEl.innerHTML = steps[step].title;
    typingTextEl.innerHTML = '';
    typeText(steps[step].message);
    if (step === steps.length - 1) {
        nextBtn.disabled = true;
        nextBtn.innerHTML = 'Selesai';
        startConfetti();
    }
}

nextBtn.addEventListener('click', () => {
    if (currentStep < steps.length - 1) {
        currentStep++;
        showStep(currentStep);
    }
});

showStep(currentStep);

// Balon
function createBalloon(color, leftPercent, delay) {
    const ns = "http://www.w3.org/2000/svg";
    let svg = document.createElementNS(ns, "svg");
    svg.classList.add('balloon');
    svg.style.left = leftPercent + 'vw';
    svg.style.animationDuration = (5 + Math.random()*3) + 's';
    svg.style.animationDelay = delay + 's';
    svg.style.fill = color;

    let ellipse = document.createElementNS(ns, 'ellipse');
    ellipse.setAttribute('cx', 20);
    ellipse.setAttribute('cy', 30);
    ellipse.setAttribute('rx', 15);
    ellipse.setAttribute('ry', 23);
    ellipse.setAttribute('fill', color);

    let circle = document.createElementNS(ns, 'circle');
    circle.setAttribute('cx', 12);
    circle.setAttribute('cy', 18);
    circle.setAttribute('r', 8);
    circle.setAttribute('fill', 'rgba(255,255,255,0.4)');

    let string = document.createElementNS(ns, 'line');
    string.setAttribute('x1', 20);
    string.setAttribute('y1', 53);
    string.setAttribute('x2', 20);
    string.setAttribute('y2', 72);
    string.setAttribute('stroke', '#444');
    string.setAttribute('stroke-width', 2);

    svg.appendChild(ellipse);
    svg.appendChild(circle);
    svg.appendChild(string);
    return svg;
}
const balloonColors = ['#4a90e2', '#5dade2', '#2980b9', '#85c1e9'];
const balloonContainer = document.getElementById('balloonContainer');
for(let i=0; i<10; i++){
    let color = balloonColors[i % balloonColors.length];
    let left = Math.random() * 95;
    let delay = Math.random() * 5;
    let b = createBalloon(color, left, delay);
    balloonContainer.appendChild(b);
}

// Konfeti
(() => {
    const confettiCount = 100;
    const canvas = document.getElementById('confettiCanvas');
    const ctx = canvas.getContext('2d');
    let W = window.innerWidth;
    let H = window.innerHeight;
    canvas.width = W;
    canvas.height = H;

    const colors = ['#4a90e2','#85c1e9','#d6eaf8','#2980b9','#bbdefb'];
    class Confetti {
        constructor(){
            this.x = Math.random() * W;
            this.y = Math.random() * -H;
            this.r = Math.random() * 6 + 4;
            this.color = colors[Math.floor(Math.random() * colors.length)];
            this.tilt = Math.floor(Math.random() * 10) - 10;
            this.tiltAngle = 0;
            this.tiltAngleIncrement = Math.random() * 0.07 + 0.05;
            this.speedY = Math.random() * 3 + 2;
        }
        update(){
            this.y += this.speedY;
            this.tiltAngle += this.tiltAngleIncrement;
            this.tilt = Math.sin(this.tiltAngle) * 15;
            if(this.y > H) {
                this.x = Math.random() * W;
                this.y = -10;
            }
        }
        draw(){
            ctx.beginPath();
            ctx.lineWidth = this.r / 2;
            ctx.strokeStyle = this.color;
            ctx.moveTo(this.x + this.tilt + this.r / 2, this.y);
            ctx.lineTo(this.x + this.tilt, this.y + this.tilt + this.r / 2);
            ctx.stroke();
        }
    }

    let confettis = [];
    let animationId;

    function initConfetti() {
        confettis = [];
        for(let i=0; i < confettiCount; i++) {
            confettis.push(new Confetti());
        }
    }

    window.startConfetti = function() {
        if(animationId) return;
        initConfetti();
        function animate(){
            ctx.clearRect(0,0,W,H);
            confettis.forEach(c => {
                c.draw();
                c.update();
            });
            animationId = requestAnimationFrame(animate);
        }
        animate();
    };

    window.addEventListener('resize', () => {
        W = window.innerWidth;
        H = window.innerHeight;
        canvas.width = W;
        canvas.height = H;
    });
})();
</script>
</body>
</html>